# R Fundamentals Day 2

# This code follows the powerpoint!

# Scalar 
a <- 15
a

# Vector
b <- c(13, 18, 19)
b

# Character
char <- "apple"
# Numeric
num <- 1:10
# Logical
logic <- TRUE
# Integer
int <- 5L

# Factor
fact <- factor(c(1, 2, 3, 1, 1, 3, 3, 4))
fact

# Changing data/class type
as.character()
as.numeric()
as.integer()
as.factor()
class(num)
num_2 <- as.numeric(num)
num_2
class(num_2)


# Matrix
m <- matrix(c(1, 2, 3, 4), nrow = 2, ncol = 2)
m
class(m)

# Data frame
o <- c("a", "b", "c")
p <- c(1, 2, 3)
n <- data.frame(o, p)
n
class(n)
class(n$o)
class(n$p)


# mtcars
mtcars

# first five rows
head(mtcars)
# last five rows
tail(mtcars)

# Labels
colnames(mtcars)
rownames(mtcars)

# drat column
mtcars$drat

# 20th value of 5th column
mtcars[20,5]

# load tidyverse
install.packages('tidyverse')
library(tidyverse)

# magrittr pracice 
mtcars %>%
  arrange(cyl) %>%
  select(mpg, hp, gear, disp) %>%
  head()

# Histogram of mpgs
ggplot(mtcars, aes(x = mpg)) + geom_histogram()

# Change bin width
ggplot(mtcars, aes(x = mpg)) + geom_histogram(binwidth = 3) 

# Label x axis
ggplot(mtcars, aes(x = mpg)) + geom_histogram() +
  xlab('Miles per Gallon')

# Save base plot as an object
hist <- ggplot(mtcars, aes(x = mpg)) + geom_histogram()
hist + xlab('Miles per Gallon')


# Exercise
hist + ylab('Counts on Y') +
  ggtitle("Histogram of Fuel Efficiency")

# Center title
hist + ylab('Counts on Y') +
  ggtitle("Histogram of Fuel Efficiency") +
  theme(plot.title = element_text(hjust = 0.5))

# Change theme
hist + theme_bw() +
  ylab('Counts on Y') +
  ggtitle("Histogram of Fuel Efficiency") +
  theme(plot.title = element_text(hjust = 0.5))

# Change theme to classic
hist + theme_classic() +
  ylab('Counts on Y') +
  ggtitle("Histogram of Fuel Efficiency") +
  theme(plot.title = element_text(hjust = 0.5))

# Scatter plot of mpg vs. weight
scatter <- ggplot(mtcars, aes(x = mpg, y = wt)) + geom_point()
scatter_lab <- scatter + theme_classic() +
  ylab('Weight') +
  xlab('Miles per Gallon') +
  ggtitle("Fuel Efficiency vs. mpg") + 
  theme(plot.title = element_text(hjust = 0.5))

scatter_lab

# Add regression line
scatter_lab + geom_smooth(method = lm)

# Remove standard error range
scatter_lab + geom_smooth(method = lm, se = F)

# Calculating p-value
mpg_wt_lm <- lm(wt~mpg, mtcars)
mpg_wt_lm

# Pulling out p-value from linear model
summary(mpg_wt_lm)
p_value <- round(summary(mpg_wt_lm)$coef[2,"Pr(>|t|)"],digits=10)
p_value

# Adding p-value to plot
p_label <- paste("p =", p_value)
p_label

scatter_lab + geom_smooth(method = lm, se = F) +
  annotate("text", x = 15, y = 2, label = p_label, size = 4)

# Box plot of cyl groups
mtcars2 <- mtcars
mtcars2$cyl <- as.factor(mtcars2$cyl)

box <- ggplot(mtcars2, aes(x = cyl, y = mpg)) + geom_boxplot()
box

# Add color and legend
box_col <- ggplot(mtcars2, aes(x = cyl, y = mpg, col = cyl)) + geom_boxplot()
box_col 
